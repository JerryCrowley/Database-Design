<?php

ini_set('display_errors', true);
ini_set('display_startup_errors', true);
error_reporting(E_ALL);

/*
$db_type           = "mysql";
$db_server         = "your_database_host_name";
$db_name           = "your_database_name";
$db_user           = "your_cims_login";
$db_password       = "your_database_password";
*/

$db_type           = "mysql";
$db_server         = "warehouse.cims.nyu.edu";
$db_name           = "jcc608_assignment6";
$db_user           = "jcc608";
$db_password       = "password";
?>
